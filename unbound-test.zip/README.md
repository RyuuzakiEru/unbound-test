# Unbound Test

Mints ERC20 tokens equal to Liquidity into Uniswap V3 NFT

Located at:
```
contracts/UniswapV3LiquidityLocker.sol
```

```
npm run compile
npm test
```
